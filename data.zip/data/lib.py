import numpy as np
import pandas as pd

## function to read dormant data

def dormant_data(path, start_date, end_date, datz=True):
    df = pd.read_parquet(path, engine='fastparquet')
    df = df.reset_index()
    date = df.pop('open_time')

    df.insert(0, 'date', date)
    # Select DataFrame rows between two dates
    mask = (df['date'] > start_date) & (df['date'] <= end_date)
    df = df.loc[mask]
    X = df.reset_index(drop=True)

    print(f'''              
    ---> Does df have NaN values ? == {X.isnull().values.any()}
    ---> Total Rows In The Data  ? == {len(X.index)}
            ''')

    if datz == False : X.pop('date')
    
    return X 

